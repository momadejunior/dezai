// Function to update HTML with fetched products
function updateProductHTML(products) {
    const container = document.getElementById('productContainer');

    // Loop through the products and update the HTML
    products.forEach(product => {
        const productElement = document.createElement('div');
        // Add a class to the dynamically created div element
        productElement.classList.add('col-md-4');

        // Customize the HTML structure based on your product display needs
        productElement.innerHTML = `
        <div class="zakas-product">
        <div class="product-inner">
            <figure class="product-image">
                <a href="product-details.html">
                    <img src="${product.images[0].url}" />
                </a>
                <div class="zakas-product-action">
                    <div class="product-action d-flex">
                        <div class="product-size">
                            <a href="" class="action-btn">
                                <span class="current"></span>
                            </a>
                            <div class="product-size-swatch">
                                <span class="product-size-swatch-btn variation-btn">
                                
                                <span class="product-size-swatch-btn variation-btn">
                              
                                </span>
                                <span class="product-size-swatch-btn variation-btn">
                               
                                </span>
                            </div>
                        </div>
                        <div class="product-color">
                            <a href="" class="action-btn">
                                <span class="current abbey"></span>
                            </a>
                            <div class="product-color-swatch">
                                <span class="product-color-swatch-btn blue variation-btn">
                      
                                </span>
                                <span class="product-color-swatch-btn copper variation-btn">
                               
                                </span>
                                <span class="product-color-swatch-btn old-rose variation-btn">
                                </span>
                            </div>
                        </div>
                        <a href="wishlist.html" class="action-btn">
                            <i class="flaticon flaticon-like"></i>
                        </a>
                        <a data-toggle="modal" data-target="#productModal" class="action-btn quick-view">
                            <i class="flaticon flaticon-eye"></i>
                        </a>
                    </div>
                </div>
                <span class="product-badge">New</span>
            </figure>
            <div class="product-info">
                <h3 class="product-title mb--15">
                    <a href="product-details.html">${product.name}</a>
                </h3>
                <div class="product-price-wrapper mb--30">
                    <span class="money">$${product.price}</span>
                    <span class="money-separator">-</span>
                    <span class="money">$200</span>
                </div>
                <a href="cart.html" class="btn btn-small btn-bg-sand btn-color-dark">Add To Cart</a>
            </div>
        </div>
    </div>
        `;
        container.appendChild(productElement);
    });
}

// Function to fetch and display products
async function fetchAndDisplayProducts() {
    try {
        const response = await fetch("https://api-us-west-2.hygraph.com/v2/clownejud6m2o01uqffrua82v/master", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                // Add any additional headers if required, such as authentication headers
            },
            body: JSON.stringify({
                query: `
                    query Collections {

                        products {
                            images {
                              url
                            }
                            name
                            price
                            variants {
                              ... on ProductSizeColorVariant {
                                id
                                name
                                size
                              }
                            }
                          }
                    }
                `,
            }),
        });

        if (!response.ok) {
            throw new Error(`GraphQL request failed with status ${response.status}`);
        }

        const responseData = await response.json();
        const { data } = responseData;
        const { products } = data;
        

        console.log(products)
        // Call a function to update the HTML with the fetched products
        updateProductHTML(products);
    } catch (error) {
        console.error('GraphQL request error:', error);
    }
}

// Call the function to fetch and display products
fetchAndDisplayProducts();
