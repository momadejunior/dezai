function updateTotal(rowId) {
    // Update total price when quantity changes
    var quantity = document.getElementById("qty-" + rowId).value;
    var price = 49.00; // Change this to the actual price of the product
    var total = (quantity * price).toFixed(2);
    document.getElementById("total-" + rowId).innerText = "$" + total;
}

function removeProduct(rowId) {
    // Remove the product row from the table
    var table = document.getElementById("cartTable");
    var row = document.getElementById("qty-" + rowId).parentNode.parentNode;
    table.deleteRow(row.rowIndex);
}

/*add to cart*/


    function addToCart(productId) {
        // Retrieve product details based on productId
        var productDetails = getProductDetails(productId);

        // Add the product to the shopping cart (you can use local storage or any other method)
        addToLocalStorageCart(productDetails);

        // Redirect to the cart page
        window.location.href = "cart.html";
    }

    function getProductDetails(productId) {
        // Replace this with your logic to retrieve product details based on productId
        // For example, you can fetch details from a server or use a predefined list
        // This is a placeholder, you should replace it with your actual logic
        return {
            id: productId,
            name: "Long Cartigen",
            price: 80, // You can adjust this based on the selected size and color
            size: getCurrentSize(productId),
            color: getCurrentColor(productId),
            // Add other relevant details
        };
    }

    // You can implement similar functions to retrieve and update the selected size and color
    function getCurrentSize(productId) {
        // Replace this with your logic to get the current selected size
        return "XL"; // Placeholder, replace it with your actual logic
    }

    function getCurrentColor(productId) {
        // Replace this with your logic to get the current selected color
        return "Abbey"; // Placeholder, replace it with your actual logic
    }

    function addToLocalStorageCart(productDetails) {
        // Retrieve existing cart items from local storage
        var existingCart = JSON.parse(localStorage.getItem("cart")) || [];

        // Add the new product to the cart
        existingCart.push(productDetails);

        // Save the updated cart back to local storage
        localStorage.setItem("cart", JSON.stringify(existingCart));
    }

